/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.awt.geom.Point2D;

/**
 *
 * @author Ewout
 */
// This class represents a single label.
public class Label {
    // The point associated with the label.
    Point2D point;
    // The height of the label.
    float height;
}
