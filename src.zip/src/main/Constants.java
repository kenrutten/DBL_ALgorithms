/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author Ewout
 */
public final class Constants {
     public static final String NORTHWEST = "NW";
    public static final String NORTHEAST = "NE";
    public static final String SOUTHWEST = "SW";
    public static final String SOUTHEAST = "SE";
    
    public static final String POS_2 = "2pos";
    public static final String POS_4 = "4pos";
    public static final String POS_SLIDER = "1slider";
}
